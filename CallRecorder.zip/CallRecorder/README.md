# Auto Call Recorder

App developed by Zaid Anwar

Automatically records phone calls and saves them inside the app.

## APK kaise banayen

**Option 1 – Android Studio**
1. Android Studio mein `File > Open` se is folder ko kholein.
2. `Build > Build APK(s)`.
3. APK yahan milegi: `app/build/outputs/apk/debug/app-debug.apk`

**Option 2 – GitHub (bina Android Studio ke)**
1. GitHub par naya repository banayen aur is folder ki saari files upload karein.
2. `Actions` tab > `Build APK` chalne dein (ya `Run workflow`).
3. Run khatam hone par `CallRecorder-APK` artifact download karein.

## Important limitations
- Android 10+ par normal apps dusre taraf ki awaaz direct record nahi kar sakti. Isliye app mic se record karti hai; samne wale ki awaaz tabhi aati hai jab call speaker par ho. Kuch phones (ya purane Android) par dono taraf record ho jati hai.
- Background mein chalne ke liye app mein "Allow background running" dabayen aur battery optimization band karein. Kuch brands (Xiaomi, Oppo, Vivo, Samsung) mein autostart bhi on karna parta hai.
- Aapke area ke qanoon ke mutabiq call record karne se pehle samne wale ki ijazat zaroori ho sakti hai.
