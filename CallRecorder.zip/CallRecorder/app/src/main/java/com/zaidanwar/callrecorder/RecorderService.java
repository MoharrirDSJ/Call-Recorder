package com.zaidanwar.callrecorder;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.IBinder;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Foreground service that records audio while a call is active. */
public class RecorderService extends Service {

    private static final String CHANNEL_ID = "call_recording";
    private MediaRecorder recorder;

    public static File recordingsDir(android.content.Context c) {
        File dir = new File(c.getExternalFilesDir(null), "CallRecordings");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        createChannel();
        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Call recording")
                .setContentText("Recording the current call...")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build();

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(1, notification);
        }

        if (recorder == null) startRecording();
        return START_NOT_STICKY;
    }

    private void startRecording() {
        String name = "call_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".m4a";
        File out = new File(recordingsDir(this), name);

        // VOICE_CALL captures both sides but is blocked on most phones (Android 10+).
        // Fall back to the best sources a normal app is allowed to use.
        int[] sources = {
                MediaRecorder.AudioSource.VOICE_CALL,
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                MediaRecorder.AudioSource.MIC
        };

        for (int source : sources) {
            MediaRecorder r = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(this) : new MediaRecorder();
            try {
                r.setAudioSource(source);
                r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                r.setAudioEncodingBitRate(128000);
                r.setAudioSamplingRate(44100);
                r.setOutputFile(out.getAbsolutePath());
                r.prepare();
                r.start();
                recorder = r;
                return;
            } catch (Exception e) {
                try { r.release(); } catch (Exception ignored) { }
            }
        }
        stopSelf();
    }

    private void createChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Call recording", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }

    @Override
    public void onDestroy() {
        if (recorder != null) {
            try { recorder.stop(); } catch (Exception ignored) { }
            try { recorder.release(); } catch (Exception ignored) { }
            recorder = null;
        }
        super.onDestroy();
    }
}
