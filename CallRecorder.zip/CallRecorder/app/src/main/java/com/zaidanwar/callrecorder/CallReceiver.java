package com.zaidanwar.callrecorder;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;

/** Listens for phone state changes and starts/stops the recorder service. */
public class CallReceiver extends BroadcastReceiver {

    private static String lastState = TelephonyManager.EXTRA_STATE_IDLE;

    @Override
    public void onReceive(Context context, Intent intent) {
        String state = intent.getStringExtra(TelephonyManager.EXTRA_STATE);
        if (state == null || state.equals(lastState)) return;
        lastState = state;

        boolean enabled = context.getSharedPreferences("prefs", Context.MODE_PRIVATE)
                .getBoolean("enabled", true);
        if (!enabled) return;

        Intent service = new Intent(context, RecorderService.class);
        try {
            if (TelephonyManager.EXTRA_STATE_OFFHOOK.equals(state)) {
                // Call connected (incoming answered or outgoing placed)
                context.startForegroundService(service);
            } else if (TelephonyManager.EXTRA_STATE_IDLE.equals(state)) {
                // Call ended
                context.stopService(service);
            }
        } catch (Exception ignored) {
            // Android may refuse to start a mic service from background on some devices
        }
    }
}
