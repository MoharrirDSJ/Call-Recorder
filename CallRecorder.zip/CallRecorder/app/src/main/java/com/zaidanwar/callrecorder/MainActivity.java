package com.zaidanwar.callrecorder;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {

    private final List<File> files = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private MediaPlayer player;
    private TextView emptyView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences prefs = getSharedPreferences("prefs", Context.MODE_PRIVATE);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("Auto Call Recorder");
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView credit = new TextView(this);
        credit.setText("App developed by Zaid Anwar");
        credit.setTextSize(14);
        credit.setTextColor(Color.GRAY);
        credit.setPadding(0, 0, 0, pad);
        root.addView(credit);

        Switch enable = new Switch(this);
        enable.setText("Record every call automatically");
        enable.setChecked(prefs.getBoolean("enabled", true));
        enable.setOnCheckedChangeListener((b, checked) ->
                prefs.edit().putBoolean("enabled", checked).apply());
        root.addView(enable);

        Button perms = new Button(this);
        perms.setText("Grant permissions");
        perms.setOnClickListener(v -> requestAllPermissions());
        root.addView(perms);

        Button battery = new Button(this);
        battery.setText("Allow background running (battery)");
        battery.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)));
        root.addView(battery);

        TextView note = new TextView(this);
        note.setText("Recordings are saved inside the app. Tap to play/stop, long-press to delete. "
                + "Please make sure you have consent to record calls where the law requires it.");
        note.setTextSize(12);
        note.setPadding(0, pad / 2, 0, pad / 2);
        root.addView(note);

        ListView list = new ListView(this);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>());
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, pos, id) -> togglePlay(files.get(pos)));
        list.setOnItemLongClickListener((parent, view, pos, id) -> {
            File f = files.get(pos);
            if (f.delete()) refreshList();
            return true;
        });
        root.addView(list, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        emptyView = new TextView(this);
        emptyView.setText("No recordings yet");
        emptyView.setGravity(Gravity.CENTER);
        root.addView(emptyView);

        setContentView(root);
        requestAllPermissions();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshList();
    }

    @Override
    protected void onDestroy() {
        stopPlayback();
        super.onDestroy();
    }

    private void requestAllPermissions() {
        List<String> needed = new ArrayList<>(Arrays.asList(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_PHONE_STATE));
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.POST_NOTIFICATIONS);

        List<String> missing = new ArrayList<>();
        for (String p : needed) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) missing.add(p);
        }
        if (!missing.isEmpty()) {
            requestPermissions(missing.toArray(new String[0]), 1);
        } else {
            Toast.makeText(this, "All permissions granted", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshList() {
        files.clear();
        File[] found = RecorderService.recordingsDir(this).listFiles();
        if (found != null) {
            files.addAll(Arrays.asList(found));
            Collections.sort(files, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
        }
        adapter.clear();
        for (File f : files) {
            adapter.add(f.getName() + "  (" + (f.length() / 1024) + " KB)");
        }
        adapter.notifyDataSetChanged();
        emptyView.setVisibility(files.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void togglePlay(File file) {
        if (player != null) {
            stopPlayback();
            return;
        }
        try {
            player = new MediaPlayer();
            player.setDataSource(file.getAbsolutePath());
            player.setOnCompletionListener(mp -> stopPlayback());
            player.prepare();
            player.start();
        } catch (Exception e) {
            Toast.makeText(this, "Cannot play this file", Toast.LENGTH_SHORT).show();
            stopPlayback();
        }
    }

    private void stopPlayback() {
        if (player != null) {
            try { player.release(); } catch (Exception ignored) { }
            player = null;
        }
    }
}
